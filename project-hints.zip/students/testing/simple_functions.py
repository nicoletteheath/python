def function_1():
    return "Output for function 1."


def function_2():
    return "Broken output for function 2."


def function_3(name):
    return "x = 3"


def function_4(x, y):
    return x + y

